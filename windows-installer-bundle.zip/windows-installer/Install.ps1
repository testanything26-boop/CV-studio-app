# CV Studio post-install setup — creates the venv and installs packages.
# Runs automatically inside the installer; can also be run manually by
# right-clicking it -> "Run with PowerShell" (needs internet).
$ErrorActionPreference = "Stop"
Set-Location -Path (Split-Path -Parent $MyInvocation.MyCommand.Path)

function Find-Python {
  $cands = @(
    @{ exe = "py";     args = @("-3") },
    @{ exe = "python"; args = @() }
  )
  foreach ($c in $cands) {
    try {
      $v = & $c.exe @($c.args + @("-c", "import sys; print('%d.%d' % sys.version_info[:2])")) 2>$null
      if ($LASTEXITCODE -eq 0 -and $v) {
        $p = $v.Trim() -split "\."
        if ([int]$p[0] -gt 3 -or ([int]$p[0] -eq 3 -and [int]$p[1] -ge 10)) {
          return $c
        }
      }
    } catch {}
  }
  $local = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
  if (Test-Path $local) { return @{ exe = $local; args = @() } }
  return $null
}

$py = Find-Python
if (-not $py) { Write-Error "No Python 3.10+ found."; exit 1 }
Write-Host "Using Python: $($py.exe) $($py.args)"

& $py.exe @($py.args + @("-m", "venv", "venv"))
if ($LASTEXITCODE -ne 0) { Write-Error "venv creation failed."; exit 1 }
& ".\venv\Scripts\python.exe" -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { Write-Error "pip upgrade failed."; exit 1 }
& ".\venv\Scripts\python.exe" -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { Write-Error "package install failed."; exit 1 }
Write-Host "CV Studio setup complete."
