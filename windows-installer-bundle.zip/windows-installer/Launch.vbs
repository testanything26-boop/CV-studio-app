' CV Studio launcher — starts the app with no console window.
' The app opens your browser to http://127.0.0.1:8901 by itself.
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
pyw = appDir & "\venv\Scripts\pythonw.exe"
If Not fso.FileExists(pyw) Then
  MsgBox "CV Studio is not fully installed (Python environment is missing)." & vbCrLf & vbCrLf & _
         "Please run the setup again with an internet connection.", vbExclamation, "CV Studio"
  WScript.Quit 1
End If
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = appDir
sh.Run """" & pyw & """ -m studio.main", 0, False
