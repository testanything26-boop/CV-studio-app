CV STUDIO v1.0 — Background Changer + Face Swap in one app
=========================================================

WHAT IT IS
  One app with two tools for your product photos:
  - Background Changer: AI background removal, 100 studio backdrops,
    cutout editor, bulk mode, AI shadows
  - Face Swap: swap model faces on product photos (100% local AI)
  Sign-in is required. New accounts must be approved by the admin (you).

INSTALL (one time)
  Mac:
    1. Unzip this file.
    2. Double-click INSTALL.command (needs internet, a few minutes).
       If macOS blocks it: right-click > Open.
  Windows:
    1. Unzip this file.
    2. Install Python 3 from https://www.python.org/downloads/
       (tick "Add python.exe to PATH" during setup) — skip if installed.
    3. Double-click INSTALL.bat (needs internet, a few minutes).
       A desktop shortcut is created.

RUN
  Mac: double-click START.command
  Windows: double-click START.bat (or the desktop shortcut)
  Your browser opens to CV Studio. Sign in with your approved account.

FIRST-TIME SERVER SETUP (you, the admin, do this once)
  The app signs in against a small login server. To create it:
  1. On github.com, create a new repo named cv-studio-auth.
     Upload these 3 files from the cv-studio-auth-backend.zip:
     main.py, requirements.txt, README.md (use Add file > Upload files).
  2. On render.com: New > Web Service > connect the repo.
     Build command: pip install -r requirements.txt
     Start command:  uvicorn main:app --host 0.0.0.0 --port $PORT
     Plan: Free. Add environment variable ADMIN_KEY = a long secret
     only you know. Deploy.
  3. Copy your service URL, e.g. https://cv-studio-auth.onrender.com
  4. In CV Studio's login page, click "Login server address" and paste it.
  5. Register your own account in the app, then open
     https://<your-url>/admin, enter the ADMIN_KEY, and approve yourself.
  6. Approve staff accounts the same way. Reject/disable anytime.

NOTES
  - Internet is needed to sign in. After sign-in the app works offline;
    sessions last 30 days.
  - Face Swap downloads its AI models on first use (~1.2 GB, one time).
  - Background Changer downloads its AI model on first use (~40 MB).
  - Nothing you process is uploaded anywhere — both tools run on your computer.
  - The login server keeps only names, emails and password hashes.
    On Render's free tier its disk can reset on redeploy; if that happens,
    people just register again and you re-approve (takes a minute).
