"""Login client for CV Studio — talks to the cloud auth backend.

Token is cached locally (~/.cvstudio/token.json) for 30 days so the app
keeps working offline after the first login. Login/registration need
internet; afterwards only re-validation needs it.
"""
import json
import time
import urllib.request
import urllib.error
from pathlib import Path

TOKEN_FILE = Path.home() / ".cvstudio" / "token.json"
TOKEN_DAYS = 30


def auth_url():
    from . import config
    return config.get("auth_url", "").rstrip("/")


def _post(path, payload, timeout=20):
    url = auth_url() + path
    if not url or url == path:
        raise RuntimeError("Auth server URL is not set. Ask the admin.")
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            detail = json.load(e).get("detail", "")
        except Exception:
            detail = ""
        raise RuntimeError(detail or f"Server error ({e.code})")
    except urllib.error.URLError:
        raise RuntimeError("No internet connection to the login server.")


def _check(token, timeout=15):
    """Returns (ok, offline)."""
    req = urllib.request.Request(
        auth_url() + "/api/me",
        headers={"Authorization": "Bearer " + token},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.load(r)
            return True, False
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return False, False  # revoked / disabled
        return False, True
    except Exception:
        return False, True  # no internet


def revalidate():
    """Refresh the cached session against the server when online.

    Offline -> keep the cached session (30-day grace).
    Server says invalid -> session cleared (account disabled).
    Returns the session dict, or None."""
    sess = load_session()
    if not sess:
        return None
    ok, offline = _check(sess["token"])
    if ok:
        sess["validated_at"] = time.time()
        save_session(sess["token"], sess.get("name", ""),
                     sess.get("email", ""))
        return sess
    if offline:
        return sess
    clear_session()
    return None


def save_session(token, name, email):
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps({
        "token": token, "name": name, "email": email,
        "validated_at": time.time(),
    }))
    try:
        TOKEN_FILE.chmod(0o600)
    except Exception:
        pass


def load_session():
    try:
        d = json.loads(TOKEN_FILE.read_text())
        if time.time() - d.get("validated_at", 0) > TOKEN_DAYS * 86400:
            return None
        return d
    except Exception:
        return None


def clear_session():
    try:
        TOKEN_FILE.unlink()
    except Exception:
        pass


def login(email, password):
    d = _post("/api/login", {"email": email, "password": password})
    save_session(d["token"], d.get("name", ""), d.get("email", email))
    return d


def register(name, email, password):
    return _post("/api/register",
                 {"name": name, "email": email, "password": password})


def revalidate():
    """Refresh the cached session against the server when online.

    Offline -> keep the cached session (30-day grace).
    Server says invalid -> session cleared (account disabled).
    Returns the session dict, or None."""
    sess = load_session()
    if not sess:
        return None
    ok, offline = _check(sess["token"])
    if ok:
        sess["validated_at"] = time.time()
        save_session(sess["token"], sess.get("name", ""),
                     sess.get("email", ""))
        return sess
    if offline:
        return sess
    clear_session()
    return None
