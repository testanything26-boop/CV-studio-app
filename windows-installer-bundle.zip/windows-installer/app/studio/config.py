"""CV Studio configuration — auth server URL lives here."""
import json
from pathlib import Path

CONFIG_FILE = Path(__file__).parent.parent / "config.json"

_defaults = {
    # Set this to your deployed auth backend URL, e.g.
    # "https://cv-studio-auth.onrender.com"
    "auth_url": "https://cv-studio-auth.onrender.com",
    "port": 8901,
}


def get(key, default=None):
    try:
        d = json.loads(CONFIG_FILE.read_text())
    except Exception:
        d = {}
    return d.get(key, _defaults.get(key, default))


def set(key, value):
    try:
        d = json.loads(CONFIG_FILE.read_text())
    except Exception:
        d = {}
    d[key] = value
    CONFIG_FILE.write_text(json.dumps(d, indent=2))
