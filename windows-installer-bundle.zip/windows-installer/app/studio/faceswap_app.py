"""Face Swap engine for CV Studio — 100% local face swapping for product photos.

Same engine as face-swap v1.0.6, refactored so the AI models load lazily
on the first swap (fast app startup). Exposes `demo` (gradio Blocks) for
mounting inside the CV Studio FastAPI app.

v1.1: first-run progress reporting — the swap shows live status
(downloading X of Y MB, loading detector, swapping) instead of a bare
spinner while the ~1.2 GB of AI models download once.
"""
import os
import glob
import threading
import time
import urllib.request

import cv2
import numpy as np
import gradio as gr
import insightface
from insightface.app import FaceAnalysis

BASE = os.path.dirname(os.path.abspath(__file__))
FACES_DIR = os.path.join(BASE, "faces")
MODELS_DIR = os.path.join(BASE, "models")
OUT_DIR = os.path.join(BASE, "output")
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

INSWAPPER_URL = ("https://github.com/deepinsight/insightface/releases/"
                 "download/model-zoo/inswapper_128.onnx")
GFPGAN_URL = ("https://huggingface.co/Neus/GFPGANv1.4/"
              "resolve/main/GFPGANv1.4.onnx")


def _download(url, dst, prog=None, label="file"):
    """Chunked download with optional progress updates.

    prog is a dict; sets prog["msg"]. Retries with the certifi CA bundle
    on SSL errors (Mac python.org Python ships without certificates).
    """
    import ssl

    def attempt(ctx):
        req = urllib.request.Request(
            url, headers={"User-Agent": "CVStudio/1.0"})
        with urllib.request.urlopen(req, context=ctx) as r, \
                open(dst, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if prog is not None:
                    if total:
                        prog["msg"] = (
                            f"Downloading {label}: "
                            f"{done // 1048576} of {total // 1048576} MB "
                            f"({100 * done // total}%) — first run only, "
                            f"keep this page open")
                    else:
                        prog["msg"] = (
                            f"Downloading {label}: {done // 1048576} MB "
                            f"— first run only, keep this page open")

    try:
        attempt(None)
    except Exception as e:
        if os.path.exists(dst):
            os.remove(dst)
        if not _is_tls_error(e):
            raise
        # Mac python.org Python ships without certificates, and some
        # networks intercept TLS — retry once with the certifi CA bundle.
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
        attempt(ctx)


def _is_tls_error(e):
    seen = set()
    while e is not None and id(e) not in seen:
        seen.add(id(e))
        if isinstance(e, ssl.SSLError):
            return True
        if "CERTIFICATE" in str(e):
            return True
        e = e.__cause__ or e.__context__
    return False


def ensure_models(prog=None):
    jobs = [
        (os.path.join(MODELS_DIR, "inswapper_128.onnx"), INSWAPPER_URL,
         "face-swap model (~550 MB)"),
        (os.path.join(MODELS_DIR, "GFPGANv1.4.onnx"), GFPGAN_URL,
         "face sharpener (~340 MB)"),
    ]
    for dst, url, label in jobs:
        if not os.path.exists(dst):
            print(f"Downloading {label}, one time, needs internet)...",
                  flush=True)
            _download(url, dst, prog, label)
            print("done.", flush=True)
    return jobs[0][0]


_engine = {}


def get_engine(prog=None):
    """Load models on first use; returns (face_analyser, swapper)."""
    if "fa" not in _engine:
        def msg(m):
            print("Face Swap:", m, flush=True)
            if prog is not None:
                prog["msg"] = m

        msg("Checking AI models (first run downloads ~1 GB, one time)...")
        model_path = ensure_models(prog)
        msg("Loading face detector (first run fetches its data ~300 MB)...")
        fa = FaceAnalysis(name="buffalo_l")
        fa.prepare(ctx_id=-1, det_size=(640, 640))  # CPU
        msg("Loading face swapper...")
        swapper = insightface.model_zoo.get_model(model_path)
        _engine["fa"] = fa
        _engine["swapper"] = swapper
        msg("Models ready.")
    return _engine["fa"], _engine["swapper"]


def biggest(faces):
    return max(faces,
               key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))


_gfpgan_sess = None


def _get_gfpgan():
    global _gfpgan_sess
    if _gfpgan_sess is None:
        import onnxruntime as ort
        _gfpgan_sess = ort.InferenceSession(
            os.path.join(MODELS_DIR, "GFPGANv1.4.onnx"),
            providers=["CPUExecutionProvider"])
    return _gfpgan_sess


def sharpen_face(img, fa):
    """Enhance the largest face in img with GFPGAN (sharpens the swap)."""
    from insightface.utils import face_align
    sess = _get_gfpgan()
    faces = fa.get(img)
    if not faces:
        return img
    face = biggest(faces)
    M = face_align.estimate_norm(face.kps, 512, mode="arcface")
    aligned = cv2.warpAffine(img, M, (512, 512),
                             borderMode=cv2.BORDER_REPLICATE)
    blob = cv2.cvtColor(aligned, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    blob = np.transpose(blob, (2, 0, 1))[None]
    out = sess.run(None, {"input": blob})[0]
    enh = np.clip(out[0].transpose(1, 2, 0), 0, 1)
    enh = (enh * 255).astype(np.uint8)
    enh = cv2.cvtColor(enh, cv2.COLOR_RGB2BGR)
    # match GFPGAN output colour to the original crop
    for c in range(3):
        o = aligned[:, :, c].astype(np.float32)
        e = enh[:, :, c].astype(np.float32)
        e = (e - e.mean()) * (o.std() / (e.std() + 1e-6)) + o.mean()
        enh[:, :, c] = np.clip(e, 0, 255).astype(np.uint8)
    # paste back over the face oval only (no box seams)
    M_inv = cv2.invertAffineTransform(M)
    h, w = img.shape[:2]
    restored = cv2.warpAffine(enh, M_inv, (w, h),
                              borderMode=cv2.BORDER_TRANSPARENT)
    mask = np.zeros((512, 512), np.float32)
    cv2.ellipse(mask, (256, 235), (165, 195), 0, 0, 360, 1.0, -1)
    mask = cv2.GaussianBlur(mask, (0, 0), 28)
    mask = cv2.warpAffine(mask, M_inv, (w, h))[..., None]
    return (restored.astype(np.float32) * mask
            + img.astype(np.float32) * (1 - mask)).astype(np.uint8)


face_files = sorted(glob.glob(os.path.join(FACES_DIR, "face-*.webp")))
face_names = [f"Face {i + 1}" for i in range(len(face_files))]
CHOICES = ["Keep original face"] + face_names + ["Custom upload"]


def swap_face(target_path, choice, custom_path, sharpen):
    """Generator: yields (image, file, status) so the UI shows live progress
    while models download / load on the first run."""
    if not target_path:
        raise gr.Error("Upload a product photo first.")

    prog = {"msg": "Starting...", "error": None}
    box = {}

    def worker():
        try:
            box["engine"] = get_engine(prog)
        except Exception as e:  # noqa: BLE001
            prog["error"] = str(e)

    t = threading.Thread(target=worker, daemon=True)
    t.start()
    while t.is_alive():
        yield None, None, prog["msg"]
        time.sleep(0.4)
    t.join()
    if prog["error"]:
        raise gr.Error("Could not set up the AI models: " + prog["error"])
    fa, swapper = box["engine"]

    yield None, None, "Reading photos..."
    target = cv2.imread(target_path)
    if target is None:
        raise gr.Error("Could not read the product photo.")
    t_faces = fa.get(target)
    if not t_faces:
        raise gr.Error("No face found in the product photo. "
                       "Try a clearer front-facing shot.")

    if choice == "Keep original face":
        yield None, None, "Keeping original face..."
        result = target.copy()
    else:
        if choice == "Custom upload":
            if not custom_path:
                raise gr.Error("Upload a custom face photo, or pick a "
                               "built-in face.")
            src_path = custom_path
        else:
            src_path = face_files[face_names.index(choice)]
        source = cv2.imread(src_path)
        if source is None:
            raise gr.Error("Could not read the face image.")
        yield None, None, "Finding faces..."
        s_faces = fa.get(source)
        if not s_faces:
            raise gr.Error("No face found in the chosen face image.")
        yield None, None, "Swapping..."
        result = swapper.get(target, biggest(t_faces), biggest(s_faces),
                             paste_back=True)

    if sharpen:
        yield None, None, "Sharpening the face..."
        result = sharpen_face(result, fa)
    out_path = os.path.join(OUT_DIR, "swapped.png")
    cv2.imwrite(out_path, result)
    yield out_path, out_path, "Done — download your image below."


with gr.Blocks(title="Face Swap") as demo:
    gr.Markdown(
        "# Face Swap\n"
        "Upload a product photo, pick a model face, "
        "swap. Runs fully on this computer — nothing is uploaded anywhere."
    )
    with gr.Row():
        with gr.Column():
            target_in = gr.Image(type="filepath", label="1. Product photo")
            face_choice = gr.Radio(choices=CHOICES,
                                   value=CHOICES[1] if len(CHOICES) > 1
                                   else CHOICES[0],
                                   label="2. Model face")
            custom_in = gr.Image(
                type="filepath",
                label="Custom face photo (only needed if 'Custom upload' "
                      "chosen)")
            sharpen_in = gr.Checkbox(
                value=True,
                label="Sharpen face (recommended — fixes soft/low-detail "
                      "faces)")
            btn = gr.Button("Swap face", variant="primary")
        with gr.Column():
            result_out = gr.Image(label="Result")
            status_out = gr.Textbox(label="Status", interactive=False,
                                    value="Idle.")
            dl = gr.File(label="Download result")
    btn.click(swap_face,
              inputs=[target_in, face_choice, custom_in, sharpen_in],
              outputs=[result_out, dl, status_out])
    gr.Markdown(
        "_First swap downloads the AI models once (~1.2 GB) — the Status box "
        "shows progress. After that, swaps take seconds._<br>"
        "_Tip: built-in faces live in the `faces` folder — drop in your own "
        "`face-11.webp`, `face-12.webp`… and restart to extend the catalog._"
    )


if __name__ == "__main__":
    demo.launch(server_name="127.0.0.1", server_port=7870)
