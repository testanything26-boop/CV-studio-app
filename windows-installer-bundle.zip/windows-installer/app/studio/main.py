"""CV Studio — one app combining Background Changer and Face Swap.

Login-gated: internet is needed to log in (accounts are approved by the
admin on the auth server). After login the session is cached for 30 days,
so the tools keep working offline.
"""
import hmac
import threading
import time
from pathlib import Path

import gradio as gr
from fastapi import FastAPI, Request
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                               RedirectResponse)

from . import auth_client, config
from .faceswap_app import demo as faceswap_demo

BASE = Path(__file__).parent
STATIC = BASE / "static"

app = FastAPI(title="CV Studio")

PUBLIC_PATHS = {"/login", "/api/local/login", "/api/local/register",
                "/api/local/config", "/api/health"}
_last_reval = 0.0


def _maybe_revalidate():
    global _last_reval
    now = time.time()
    if now - _last_reval > 3600:
        _last_reval = now
        t = threading.Thread(target=auth_client.revalidate, daemon=True)
        t.start()


@app.middleware("http")
async def login_gate(request: Request, call_next):
    path = request.url.path
    if path in PUBLIC_PATHS or path.startswith("/static/"):
        return await call_next(request)
    token = request.cookies.get("cvstudio_token", "")
    sess = auth_client.load_session()
    if (sess and token
            and hmac.compare_digest(token, sess.get("token", ""))):
        _maybe_revalidate()
        return await call_next(request)
    if path.startswith("/api/"):
        return JSONResponse({"error": "login required"}, status_code=401)
    return RedirectResponse("/login", status_code=303)


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/login", response_class=HTMLResponse)
def login_page():
    return (STATIC / "login.html").read_text()


@app.post("/api/local/login")
async def local_login(request: Request):
    body = await request.json()
    try:
        d = auth_client.login(body.get("email", "").strip(),
                              body.get("password", ""))
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    resp = JSONResponse({"ok": True, "name": d.get("name", "")})
    resp.set_cookie("cvstudio_token", d["token"], httponly=True,
                    samesite="lax", max_age=30 * 86400)
    return resp


@app.post("/api/local/register")
async def local_register(request: Request):
    body = await request.json()
    try:
        d = auth_client.register(body.get("name", "").strip(),
                                 body.get("email", "").strip(),
                                 body.get("password", ""))
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return JSONResponse(d)


@app.get("/api/local/config")
def local_config_get():
    from . import config as cfg
    return {"auth_url": cfg.get("auth_url", "")}


@app.post("/api/local/config")
async def local_config_set(request: Request):
    from . import config as cfg
    body = await request.json()
    url = body.get("auth_url", "").strip().rstrip("/")
    if not url.startswith("https://"):
        return JSONResponse(
            {"error": "URL must start with https://"}, status_code=400)
    cfg.set("auth_url", url)
    return {"ok": True, "auth_url": url}


@app.post("/api/local/logout")
def local_logout():
    auth_client.clear_session()
    resp = JSONResponse({"ok": True})
    resp.delete_cookie("cvstudio_token")
    return resp


@app.get("/api/local/me")
def local_me(request: Request):
    token = request.cookies.get("cvstudio_token", "")
    sess = auth_client.load_session()
    if sess and hmac.compare_digest(token, sess.get("token", "")):
        return {"name": sess.get("name", ""), "email": sess.get("email", "")}
    return JSONResponse({"error": "login required"}, status_code=401)


@app.get("/", response_class=HTMLResponse)
def home():
    return (STATIC / "home.html").read_text()


@app.get("/bg")
def bg_tool():
    return FileResponse(STATIC / "bg.html")


# Face Swap (Gradio) mounted under /faceswap — models load on first swap.
app = gr.mount_gradio_app(app, faceswap_demo, path="/faceswap")


def run():
    import uvicorn
    import webbrowser
    port = int(config.get("port", 8901))
    print(f"CV Studio starting on http://127.0.0.1:{port}", flush=True)
    threading.Timer(1.5,
                    lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    run()
