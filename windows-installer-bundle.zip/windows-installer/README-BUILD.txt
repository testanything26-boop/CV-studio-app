BUILDING THE WINDOWS INSTALLER — Setup-CVStudio-1.1.exe
=========================================================
You only need to upload ONE file to GitHub. The build happens
automatically there — no folders to upload one by one.

STEP 1 — Upload the bundle (one file)
1. Create a new GitHub repository (any name, e.g. "cv-studio").
2. On the repo page: Add file -> Upload files.
3. Drag in  windows-installer-bundle.zip  (about 13 MB).
   Keep the file name exactly as it is; upload to the main folder.
4. Commit changes.

STEP 2 — Add the build recipe (one file, copy-paste)
1. In the repo: Add file -> Create new file.
2. In the filename box type exactly:
     .github/workflows/build-installer.yml
   GitHub creates the folders automatically.
3. Paste the recipe text (it is printed in the chat message
   alongside this zip, and also saved inside the bundle as
   github-workflow-build-installer.yml).
4. Commit changes.

STEP 3 — Build and download
1. Go to the Actions tab -> "Build Windows installer" ->
   "Run workflow" -> Run workflow.
2. After a few minutes it turns green. Click the run, scroll to
   "Artifacts", download "CVStudio-Windows-Setup" (it arrives as
   a zip — unzip it to get Setup-CVStudio-1.1.exe).

WHAT THE INSTALLER DOES ON A WINDOWS PC
- Installs to %LocalAppData%\CVStudio (no admin rights needed)
- Installs Python 3.12 silently if no Python 3.10+ is found
- Creates the Python environment and installs all packages
  (needs internet, several minutes)
- Adds Start Menu + optional desktop shortcut; launches the app
  with no console window; the app opens http://127.0.0.1:8901
- Proper uninstaller in "Add or remove programs".
  Uninstall KEEPS the downloaded AI models (~1.2 GB), so
  reinstalling does not download them again.

OPTION B — compile on your own Windows PC (alternative)
1. Install Inno Setup 6 (free) from https://jrsoftware.org/isinfo.php
2. Download python-3.12.10-amd64.exe from
   https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe
   into the windows-installer folder (next to cv-studio.iss).
3. Open cv-studio.iss in Inno Setup, press Ctrl+F9 (Compile).
   The Setup exe appears in windows-installer/Output/.

WHAT'S IN THIS FOLDER
  cv-studio.iss                  Inno Setup script (the installer definition)
  Launch.vbs                     Silent app launcher (used by the shortcuts)
  Install.ps1                    Creates venv + installs packages (run by setup)
  app/                           The CV Studio app files (no venv, no models)
  github-workflow-build-installer.yml   The Step-2 recipe (also in chat)
