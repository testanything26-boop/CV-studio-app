; CV Studio — Inno Setup script.
; Produces a single Setup-CVStudio-1.1.exe that installs the app,
; sets up its Python environment, and adds Start Menu + desktop shortcuts.
;
; Build: install Inno Setup 6 (free, jrsoftware.org/isinfo.php),
;        open this file, press Ctrl+F9 (Compile).
;    OR: push this folder to GitHub — the included workflow builds it
;        automatically (see README-BUILD.txt).

#define MyAppName "CV Studio"
#define MyAppVersion "1.1"
#define MyAppPublisher "CV Designs and Fabrics"
#define PyInstaller "python-3.12.10-amd64.exe"

[Setup]
AppId={{C7B4E2A1-8F3D-4B6E-9A2C-5D1F8E7B6A05}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\CVStudio
DefaultGroupName=CV Studio
DisableProgramGroupPage=yes
OutputBaseFilename=Setup-CVStudio-{#MyAppVersion}
Compression=lzma2/max
SolidCompression=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern
UninstallDisplayName=CV Studio
UninstallDisplayIcon={app}\Launch.vbs

[Files]
Source: "app\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "Launch.vbs"; DestDir: "{app}"; Flags: ignoreversion
Source: "Install.ps1"; DestDir: "{app}"; Flags: ignoreversion
; Python installer is bundled when present (it is in the build folder,
; or downloaded by the GitHub workflow before compiling).
Source: "{#PyInstaller}"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{group}\CV Studio"; Filename: "{app}\Launch.vbs"; WorkingDir: "{app}"
Name: "{autodesktop}\CV Studio"; Filename: "{app}\Launch.vbs"; WorkingDir: "{app}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[UninstallDelete]
; Remove the Python environment created at install time.
Type: filesandordirs; Name: "{app}\venv"
; NOTE: studio\models (AI models downloaded on first face swap, ~1.2 GB)
; is intentionally NOT deleted, so reinstalling does not re-download them.

[Run]
; Install Python silently if none usable was found and we bundled it.
Filename: "{app}\{#PyInstaller}"; Parameters: "/quiet InstallAllUsers=0 PrependPath=1 Include_test=0"; StatusMsg: "Installing Python 3.12 (one time)..."; Check: NeedBundledPython; Flags: waituntilterminated
; Create the venv and install packages (needs internet, several minutes).
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\Install.ps1"""; StatusMsg: "Setting up CV Studio — installing packages (several minutes, needs internet)..."; Flags: waituntilterminated runhidden
; Offer to launch at the end.
Filename: "{app}\Launch.vbs"; Description: "Launch CV Studio now"; Flags: postinstall nowait skipifsilent

[Code]
function PythonOK(): Boolean;
var
  ResultCode: Integer;
begin
  Result := False;
  if Exec('py', '-3 -c "import sys; exit(0 if sys.version_info>=(3,10) else 1)"',
          '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
    if ResultCode = 0 then begin Result := True; Exit; end;
  if Exec('python', '-c "import sys; exit(0 if sys.version_info>=(3,10) else 1)"',
          '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
    if ResultCode = 0 then begin Result := True; Exit; end;
end;

function BundledPythonPresent(): Boolean;
begin
  Result := FileExists(ExpandConstant('{app}\{#PyInstaller}'));
end;

function NeedBundledPython(): Boolean;
begin
  Result := (not PythonOK()) and BundledPythonPresent();
end;

function InitializeSetup(): Boolean;
begin
  Result := True;
  if (not PythonOK()) and (not BundledPythonPresent()) then begin
    MsgBox('CV Studio needs Python 3.10 or newer (64-bit), and none was found.' + #13#10 + #13#10 +
           'Please install it from https://www.python.org/downloads/' + #13#10 +
           '(tick "Add python.exe to PATH"), then run this setup again.',
           mbError, MB_OK);
    Result := False;
  end;
end;
